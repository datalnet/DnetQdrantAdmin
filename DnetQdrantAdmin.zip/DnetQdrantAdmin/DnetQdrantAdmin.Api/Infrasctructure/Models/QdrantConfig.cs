﻿namespace Dnet.QdrantAdmin.Api.Infrasctructure.Models;

public class QdrantConfig
{
    public string QdrantServerHost { get; set; } = string.Empty;
}
