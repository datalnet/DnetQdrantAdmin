﻿namespace Dnet.QdrantAdmin.Client.Infrastructure.Enums;

public enum OverlayCurrentAction
{
    Adding = 1,
    Editing = 2,
}