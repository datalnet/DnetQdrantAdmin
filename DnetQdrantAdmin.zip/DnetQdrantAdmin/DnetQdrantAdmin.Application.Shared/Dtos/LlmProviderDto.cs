﻿namespace Dnet.QdrantAdmin.Application.Shared.Dtos;

public class LlmProviderDto
{
    public List<ModelDto> Models { get; set; } = new();
}


