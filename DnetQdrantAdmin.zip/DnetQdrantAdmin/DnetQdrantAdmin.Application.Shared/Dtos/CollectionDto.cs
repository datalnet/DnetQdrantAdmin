﻿namespace Dnet.QdrantAdmin.Application.Shared.Dtos;

public class CollectionDto
{
    public int CollectionId { get; set; }

    public string Name { get; set; } = string.Empty;
}
