﻿namespace Dnet.QdrantAdmin.Application.Shared.Dtos;

public class ValueTypeDto
{
    public int NumericValue { get; set; }

    public string StringValue { get; set; }

    public string StringKey { get; set; }

    public int NumericKey { get; set; }
}
