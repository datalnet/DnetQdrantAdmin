﻿namespace Dnet.QdrantAdmin.Application.Shared.Dtos;

public class VectorDto
{
    public long? VectorPointId { get; set; }

    public string? CollectionName { get; set; }

    public string? NoteText { get; set; }
}
