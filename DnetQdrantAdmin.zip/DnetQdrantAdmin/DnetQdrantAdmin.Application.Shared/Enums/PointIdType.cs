﻿namespace Dnet.QdrantAdmin.Application.Shared.Enums;

public enum PointIdType
{
    None = 0,
    Numerical = 1,
    Uuid = 2
}
