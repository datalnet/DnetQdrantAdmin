﻿namespace Dnet.QdrantAdmin.Application.Shared.Enums;

public enum FloatingPanelWidth
{
    Small = 380,
    Medium = 440,
    Large = 680
}